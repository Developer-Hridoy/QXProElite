<?php
// SECURITY: Keep this file outside public_html if your hosting allows it.
// If it must live here, block direct web access using .htaccess.
return [
    'db_host' => 'localhost',
    'db_name' => 'YOUR_DB_NAME',
    'db_user' => 'YOUR_DB_USER',
    'db_pass' => 'YOUR_DB_PASSWORD',
    'app_secret' => 'CHANGE_THIS_TO_A_RANDOM_64_PLUS_CHARACTER_SECRET',
    'session_name' => 'qxpro_secure_session',
];
