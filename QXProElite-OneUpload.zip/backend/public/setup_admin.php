<?php
// DELETE THIS FILE IMMEDIATELY AFTER CREATING THE FIRST ACCOUNT.
require __DIR__ . '/_bootstrap.php';
if($_SERVER['REQUEST_METHOD']==='POST'){require_csrf();$u=trim((string)($_POST['username']??''));$p=(string)($_POST['password']??'');
 if(!preg_match('/^[A-Za-z0-9_.-]{3,100}$/',$u)||strlen($p)<12||!preg_match('/[A-Z]/',$p)||!preg_match('/[a-z]/',$p)||!preg_match('/\d/',$p)||!preg_match('/[^A-Za-z0-9]/',$p))die('Use a valid username and a strong 12+ character password.');
 $stmt=db()->prepare('INSERT INTO users(username,password_hash) VALUES(?,?)');$stmt->execute([$u,password_hash($p,PASSWORD_DEFAULT)]);die('Account created. DELETE setup_admin.php NOW.');}
?><form method="post" style="max-width:420px;margin:60px auto;font:16px system-ui"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input name="username" placeholder="Username" required style="display:block;width:100%;padding:12px;margin:8px"><input type="password" name="password" placeholder="Strong password" required style="display:block;width:100%;padding:12px;margin:8px"><button style="padding:12px">Create admin</button></form>
