<?php
require __DIR__ . '/_bootstrap.php';
$u=require_login();
$html=file_get_contents(__DIR__.'/market-analysis.html');
// Add a small secure account bar without altering the original analysis engine.
$bar='<div style="position:fixed;z-index:99999;top:8px;right:8px;display:flex;gap:6px;font:12px system-ui"><a href="change-password.php" style="padding:7px 10px;border-radius:9px;background:#111;color:#fff;text-decoration:none;border:1px solid #344">🔑 Change Password</a><a href="logout.php" style="padding:7px 10px;border-radius:9px;background:#111;color:#fff;text-decoration:none;border:1px solid #344">Logout</a></div>';
$html=preg_replace('/<body([^>]*)>/i','$0'.$bar,$html,1);
echo $html;
