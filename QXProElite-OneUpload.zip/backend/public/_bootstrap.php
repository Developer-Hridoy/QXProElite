<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config/config.php';

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_secure', '1');
ini_set('session.cookie_samesite', 'Strict');
session_name($config['session_name']);
session_start();

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function db(): PDO {
    static $pdo = null;
    global $config;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
            $config['db_user'],
            $config['db_pass'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    }
    return $pdo;
}

function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function require_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Invalid request.');
    }
}
function audit(?int $uid, ?string $username, string $action): void {
    try {
        $hash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SESSION['csrf'] ?? ''));
        $stmt = db()->prepare('INSERT INTO login_audit (user_id,username,ip_hash,user_agent,action) VALUES (?,?,?,?,?)');
        $stmt->execute([$uid, $username, $hash, substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512), $action]);
    } catch (Throwable $e) { /* do not expose audit failures */ }
}
function current_user(): ?array {
    if (empty($_SESSION['uid']) || empty($_SESSION['token_version'])) return null;
    $stmt = db()->prepare('SELECT id,username,password_hash,token_version,active FROM users WHERE id=? LIMIT 1');
    $stmt->execute([(int)$_SESSION['uid']]);
    $u = $stmt->fetch();
    if (!$u || !$u['active'] || (int)$u['token_version'] !== (int)$_SESSION['token_version']) return null;
    return $u;
}
function require_login(): array {
    $u = current_user();
    if (!$u) { session_unset(); session_destroy(); header('Location: login.php'); exit; }
    return $u;
}
function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
