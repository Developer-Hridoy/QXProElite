<?php
// Copy to config.php and fill in your cPanel/MySQL details.
return [
    'db_host' => 'localhost',
    'db_name' => 'YOUR_DB_NAME',
    'db_user' => 'YOUR_DB_USER',
    'db_pass' => 'YOUR_DB_PASSWORD',
    'app_secret' => 'REPLACE_WITH_A_LONG_RANDOM_SECRET',
    'session_name' => 'qxpro_secure_session',
];
