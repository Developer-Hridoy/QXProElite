<?php require __DIR__ . '/_bootstrap.php';
if (current_user()) { header('Location: app.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  require_csrf();
  $now=time();
  if (($now-(int)($_SESSION['last_login_attempt']??0))<2) $error='Please wait a moment and try again.';
  else {
    $_SESSION['last_login_attempt']=$now;
    $username=trim((string)($_POST['username']??'')); $password=(string)($_POST['password']??'');
    $stmt=db()->prepare('SELECT * FROM users WHERE username=? LIMIT 1'); $stmt->execute([$username]); $u=$stmt->fetch();
    if ($u && $u['active'] && password_verify($password,$u['password_hash'])) {
      session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; $_SESSION['token_version']=(int)$u['token_version']; $_SESSION['csrf']=bin2hex(random_bytes(32)); audit((int)$u['id'],$u['username'],'login'); header('Location: app.php'); exit;
    }
    audit($u?(int)$u['id']:null,$username,'login_failed'); $error='Invalid username or password.';
  }
}
?><!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>QX PRO ELITE Login</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#070b12;color:#eef2f7;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.card{width:min(92vw,420px);padding:28px;border:1px solid #263247;border-radius:22px;background:#0d1420;box-shadow:0 20px 70px #0008}.brand{font-weight:900;font-size:25px;letter-spacing:.5px}.sub{color:#8fa0b8;margin:6px 0 24px}label{display:block;margin:14px 0 7px;color:#b9c5d6;font-size:13px}input{width:100%;padding:14px;border-radius:12px;border:1px solid #2a374c;background:#080d15;color:white;outline:none}button{width:100%;margin-top:20px;padding:14px;border:0;border-radius:12px;background:#fff;color:#111;font-weight:800}.err{background:#3a151a;color:#ffb7bf;border:1px solid #6e2730;padding:10px;border-radius:10px;margin-bottom:12px}.lock{font-size:36px}</style></head><body><div class="card"><div class="lock">🔐</div><div class="brand">QX PRO ELITE</div><div class="sub">Secure Market Analysis</div><?php if($error):?><div class="err"><?=e($error)?></div><?php endif;?><form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><label>Username</label><input name="username" required maxlength="100" autocomplete="username"><label>Password</label><input type="password" name="password" required maxlength="128" autocomplete="current-password"><button>SECURE LOGIN</button></form></div></body></html>
