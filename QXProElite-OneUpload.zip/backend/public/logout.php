<?php require __DIR__ . '/_bootstrap.php'; $u=current_user(); if($u)audit((int)$u['id'],$u['username'],'logout'); session_unset();session_destroy();header('Location: login.php');exit;
