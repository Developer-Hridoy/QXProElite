# WebView app: no sensitive secrets are stored in the APK.
-keepclassmembers class * extends android.webkit.WebViewClient { *; }
